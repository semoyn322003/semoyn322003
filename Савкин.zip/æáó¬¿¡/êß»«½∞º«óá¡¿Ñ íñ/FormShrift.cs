﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Использование_бд
{
    public partial class FormShrift : Form
    {
        public FormShrift()
        {
            InitializeComponent();
        }

        private void bLoadFont_Click(object sender, EventArgs e)
        {          
            InstalledFontCollection fonts = new InstalledFontCollection();          
            lbFonts.Items.Clear();          
            foreach (FontFamily font in fonts.Families)
                lbFonts.Items.Add(font.Name);

        }

        private void bBringText_Click(object sender, EventArgs e)
        {
            string[] mas = new string[5];
            mas[0] = "Снег постарел, почернел, но не горе —";
            mas[1] = "Шумным потоком быть ему вскоре!";
            mas[2] = "Солнышко щедро раскинет лучи,";
            mas[3] = "И зазвенят, заливаясь, ручьи…";
            mas[4] = "Н. Железкова";
            rtbText.Lines = mas;

            //1-я строчка            
            rtbText.SelectionStart = 0;
            rtbText.SelectionLength = 37;
            rtbText.SelectionFont = new Font("Arial", 18);
            rtbText.SelectionLength = 0;

            //2-я строчка
            rtbText.SelectionStart = 38;
            rtbText.SelectionLength = 31;
            rtbText.SelectionColor = Color.Red;
            rtbText.SelectionAlignment = HorizontalAlignment.Center;
            rtbText.SelectionFont = new Font("Arial", 18);
            rtbText.SelectionLength = 0;

            //3-я строчка
            rtbText.SelectionStart = 70;
            rtbText.SelectionLength = 29;
            rtbText.SelectionAlignment = HorizontalAlignment.Left;
            rtbText.SelectionFont = new Font("Arial", 18);
            rtbText.SelectionLength = 0;

            //4-я строчка                     
            rtbText.SelectionStart = 100;
            rtbText.SelectionLength = 29;
            rtbText.SelectionColor = Color.Red;
            rtbText.SelectionAlignment = HorizontalAlignment.Center;
            rtbText.SelectionFont = new Font("Arial", 18);
            rtbText.SelectionLength = 0;

            //5-я строчка
            rtbText.SelectionStart = 130;
            rtbText.SelectionLength = 12;
            rtbText.SelectionAlignment = HorizontalAlignment.Right;
            rtbText.SelectionFont = new Font("Times New Roman", 18);
            rtbText.SelectionLength = 0;
        }
    }
}

