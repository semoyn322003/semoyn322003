﻿namespace Использование_бд
{
    partial class FormShrift
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtbText = new System.Windows.Forms.RichTextBox();
            this.bBringText = new System.Windows.Forms.Button();
            this.lbFonts = new System.Windows.Forms.ListBox();
            this.bLoadFont = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtbText
            // 
            this.rtbText.Location = new System.Drawing.Point(268, 4);
            this.rtbText.Margin = new System.Windows.Forms.Padding(4);
            this.rtbText.Name = "rtbText";
            this.rtbText.Size = new System.Drawing.Size(609, 482);
            this.rtbText.TabIndex = 7;
            this.rtbText.Text = "";
            // 
            // bBringText
            // 
            this.bBringText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.bBringText.Font = new System.Drawing.Font("Trebuchet MS", 13.8F);
            this.bBringText.Location = new System.Drawing.Point(-4, 438);
            this.bBringText.Margin = new System.Windows.Forms.Padding(4);
            this.bBringText.Name = "bBringText";
            this.bBringText.Size = new System.Drawing.Size(264, 48);
            this.bBringText.TabIndex = 6;
            this.bBringText.Text = "Вывести текст";
            this.bBringText.UseVisualStyleBackColor = false;
            this.bBringText.Click += new System.EventHandler(this.bBringText_Click);
            // 
            // lbFonts
            // 
            this.lbFonts.FormattingEnabled = true;
            this.lbFonts.ItemHeight = 16;
            this.lbFonts.Location = new System.Drawing.Point(-4, 59);
            this.lbFonts.Margin = new System.Windows.Forms.Padding(4);
            this.lbFonts.Name = "lbFonts";
            this.lbFonts.Size = new System.Drawing.Size(263, 372);
            this.lbFonts.TabIndex = 5;
            // 
            // bLoadFont
            // 
            this.bLoadFont.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.bLoadFont.Font = new System.Drawing.Font("Trebuchet MS", 13.8F);
            this.bLoadFont.Location = new System.Drawing.Point(-4, 4);
            this.bLoadFont.Margin = new System.Windows.Forms.Padding(4);
            this.bLoadFont.Name = "bLoadFont";
            this.bLoadFont.Size = new System.Drawing.Size(264, 48);
            this.bLoadFont.TabIndex = 4;
            this.bLoadFont.Text = "Загрузить список шрифтов";
            this.bLoadFont.UseVisualStyleBackColor = false;
            this.bLoadFont.Click += new System.EventHandler(this.bLoadFont_Click);
            // 
            // FormShrift
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Plum;
            this.ClientSize = new System.Drawing.Size(871, 650);
            this.Controls.Add(this.rtbText);
            this.Controls.Add(this.bBringText);
            this.Controls.Add(this.lbFonts);
            this.Controls.Add(this.bLoadFont);
            this.Name = "FormShrift";
            this.Text = "FormShrift";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtbText;
        private System.Windows.Forms.Button bBringText;
        private System.Windows.Forms.ListBox lbFonts;
        private System.Windows.Forms.Button bLoadFont;
    }
}